python autograder.py
python pacman.py -l mediumMaze -p SearchAgent --frameTime 0
python eightpuzzle.py
python autograder.py
python pacman.py -l mediumMaze -p SearchAgent --frameTime 0


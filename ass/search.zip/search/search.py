# CSCI3230 / ESTR3108 2022-23 First Term Assignment 4
# I declare that the assignment here submitted is original except for source material explicitly acknowledged, and that the same or closely related material has not been previously submitted for another course. I also acknowledge that I am aware of University policy and regulations on honesty in academic work, and of the disciplinary guidelines and procedures applicable to breaches of such policy and regulations, as contained in the following websites.
# University Guideline on Academic Honesty: http://www.cuhk.edu.hk/policy/academichonesty/
# Faculty of Engineering Guidelines to Academic Honesty: http://www.erg.cuhk.edu.hk/erg-intra/upload/documents/ENGG_Discipline.pdf
# Student Name: Tam Rocky Lok Ki
# Student ID  : 1155158247


# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

from sys import path
import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]


"""
You only need to submit this file. Do not change other files!
Read util.py to find suitable data structure!
Try to pass all the commends in commands.txt! <--- Important
"""


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))

    Things you might used to build this algorithm:
    problem.getStartState(): 
        This gives you the starting position of pacman
    problem.isGoalState(state): 
        This checks if a state (a position) is the goal position
    problem.getSuccessors(state): 
        It returns a list of accessible children of current position 
        Structure of a child node: (position, action, cost of this move)
    util: 
        You should use the data structure provided in this file i.e, util.Stack(), util.Queue(), util.PriorityQueue()
        In this Question 1, you only need to use the data structure for iterative DFS
    a list stores the visited node:
        In graph search, we don't visit a node twice. 
    Try to write the function by yourself. You can use the example codes in tutorial slide. 
    """
    # SOLUTION 1 iterative function
    "*** YOUR CODE HERE ***"
    visited = set()
    startPath = []
    stack = util.Stack()
    stack.push((problem.getStartState(), startPath))

    # Main loop
    while not stack.isEmpty():
        element = stack.pop()
        pathTo = element[1]
        state = element[0]

        # Test for goal
        if problem.isGoalState(state):
            # Return path
            return pathTo

        # If state not in closed, add to closed and expand node.
        if state not in visited:
            visited.add(state)
            for child in problem.getSuccessors(state):
                thisPath = pathTo.copy()
                thisPath.append(child[1])
                stack.push((child[0], thisPath))
    return pathTo

    # SOLUTION 1 recursive function
    "*** YOUR CODE HERE ***"
    # def recursive_DFS(node):
    #     visited.append(node)  # append node to visited list
    #
    #     if problem.isGoalState(node[0]):
    #         return node[1]  # return action
    #
    #     for child in problem.getSuccessors(node[0]):
    #         if child[0] not in [element[0] for element in visited]:  # for child which is not in visited list
    #             temp = recursive_DFS((child[0], node[1] + [child[1]], child[2]))  # state, action, cost
    #             if temp is not None:
    #                 return temp
    #
    # visited = []
    # startPath = []
    # start = (problem.getStartState(), startPath, None)  # state, action, cost
    # return recursive_DFS(start)

    # SOLUTION 1 IDDFS (don't need to pass autograder)
    "*** YOUR CODE HERE ***"
    # def IDDFS(node, depth):
    #     visited.append(node)  # append node to visited list
    #
    #     depth += 1
    #     if depth > max_depth:
    #         pass  # exit function
    #
    #     if problem.isGoalState(node[0]):
    #         return node[1]  # return action
    #
    #     for child in problem.getSuccessors(node[0]):
    #         if child[0] not in [element[0] for element in visited]:  # for child which is not in visited list
    #             temp = IDDFS((child[0], node[1] + [child[1]], child[2]), depth)  # state, action, cost
    #             if temp is not None:
    #                 return temp
    #
    # visited = []
    # startPath = []
    # start = (problem.getStartState(), startPath, None)  # state, action, cost
    # M = 99999
    # for i in range(M):
    #     max_depth = i
    #     return IDDFS(start, 0)

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    queue = util.Queue()
    queue.push(problem.getStartState())
    visited = {}
    parents = {}
    visited[problem.getStartState()] = True
    while not (queue.isEmpty()):
        current_state = queue.pop()
        if (problem.isGoalState(current_state)):
            path = []
            while (current_state != problem.getStartState()):
                child_state, side = parents[current_state]
                path.append(side)
                current_state = child_state
            return path[::-1]
        for child_state, side, _ in problem.getSuccessors(current_state):
            if (child_state in visited):
                continue
            visited[child_state] = True
            queue.push(child_state)
            parents[child_state] = (current_state, side)
    util.raiseNotDefined()


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    fringe = util.PriorityQueue()
    distances = {}
    parents = {}
    distances[problem.getStartState()] = 0

    fringe.push(problem.getStartState(), 0)

    while not fringe.isEmpty():
        state = fringe.pop()

        if problem.isGoalState(state):
            path = []
            while state != problem.getStartState():
                child_state, side = parents[state]
                state = child_state
                path.append(side)
            return path[::-1]

        for child_state, side, cost in problem.getSuccessors(state):
            if not (child_state in distances):
                distances[child_state] = distances[state] + cost
                fringe.push(child_state, distances[child_state])
                parents[child_state] = (state, side)
            elif distances[child_state] > distances[state] + cost:
                fringe.update(child_state, distances[state] + cost)
                parents[child_state] = (state, side)
                distances[child_state] = distances[state] + cost

    util.raiseNotDefined()


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    """
    Search the node that has the lowest combined cost and heuristic first.
    heuristic_value = heuristic(the position of the pacman, problem)
    You don't need to define the heuristic. "problem" and "heuristic" are given by the function input.
    """
    "*** YOUR CODE HERE ***"
    fringe = util.PriorityQueue()
    distance = {}
    parents = {}

    fringe.push(problem.getStartState(), heuristic(problem.getStartState(), problem))
    distance[problem.getStartState()] = 0

    while not fringe.isEmpty():
        state = fringe.pop()

        if problem.isGoalState(state):
            path = []
            while (state != problem.getStartState()):
                child_state, side = parents[state]
                path.append(side)
                state = child_state
            return path[::-1]

        for child_state, side, cost in problem.getSuccessors(state):
            if child_state not in distance:
                distance[child_state] = distance[state] + cost
                fringe.push(child_state, distance[child_state] + heuristic(child_state, problem))
                parents[child_state] = (state, side)
            elif distance[child_state] > distance[state] + cost:
                distance[child_state] = distance[state] + cost
                fringe.update(child_state, distance[child_state] + heuristic(child_state, problem))
                parents[child_state] = (state, side)

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
